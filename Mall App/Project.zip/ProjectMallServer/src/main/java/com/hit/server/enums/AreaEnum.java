package com.hit.server.enums;

public enum AreaEnum {
	AREA_A, AREA_B, AREA_C, AREA_D;
}
