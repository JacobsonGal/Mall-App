package com.hit.server.enums;

public enum FloorEnum {
	FLOOR_1, FLOOR_2, FLOOR_3;
}
