import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Driver {

	public static void main(String[] args) throws FileNotFoundException, IOException {

		ObjectOutputStream out= new ObjectOutputStream(new FileOutputStream("out.txt"));
//		out.writeObject(new Student("Nissim"));
		out.writeObject(new Line(new Point(9,4), new Point(1,1)));
		
	}

}
