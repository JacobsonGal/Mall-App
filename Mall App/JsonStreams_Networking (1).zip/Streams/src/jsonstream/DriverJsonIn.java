package jsonstream;

import com.google.gson.Gson;

public class DriverJsonIn {

	public static void main(String[] args) {
		Gson gson = new Gson();

	}

}
