package jsonstream;

public class Car {

}
