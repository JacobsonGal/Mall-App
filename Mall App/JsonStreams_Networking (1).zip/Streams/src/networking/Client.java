package networking;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

import com.google.gson.Gson;

public class Client {

	public static void main(String[] args) {
		try{
			Socket myServer = new Socket("localhost", 12345);
			Gson gson = new Gson();
			PrintWriter output=new PrintWriter(myServer.getOutputStream());
			Scanner input=new Scanner(myServer.getInputStream());
			
			String s = input.nextLine();
			Student student =  gson.fromJson(s, Student.class);
			System.out.println(student);
			output.close();
			input.close();
			myServer.close();

		}catch (Exception e) {
			e.printStackTrace();
		}


	}

}
