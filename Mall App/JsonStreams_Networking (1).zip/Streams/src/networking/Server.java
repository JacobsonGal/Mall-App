package networking;

import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

import com.google.gson.Gson;

public class Server {

	public static void main(String[] args) {
		boolean serverDwon = true;
		try {
			ServerSocket server=new ServerSocket(12345);
			Socket someClient = null;
			StudentMng sm = null;
			while(serverDwon) {
				someClient = server.accept();
				sm = new StudentMng(someClient.getOutputStream(), someClient.getInputStream());
				sm.getNewUser();
			}
			server.close();
			someClient.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
