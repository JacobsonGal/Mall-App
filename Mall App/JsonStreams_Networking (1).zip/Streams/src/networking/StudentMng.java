package networking;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

import com.google.gson.Gson;

public class StudentMng {
	
	Gson gson = new Gson();
	PrintWriter output;
	Scanner input;
	
	public StudentMng(OutputStream out, InputStream in) {
		output=new PrintWriter(out);
		input=new Scanner(in);
	}
	
	public void getNewUser() {
		Student student = new Student("Nissim");
		output.println(gson.toJson(student));
		output.flush();
		output.close();
		input.close();
	}
	
	public void updateUser() {
		
	}

}
